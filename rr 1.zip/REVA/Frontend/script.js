const API_URL = 'http://localhost:5000/api/expenses';
let expenses = [];
let pieChart, barChart;

// Format numbers as Indian Rupees (INR)
const currencyFormatter = new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' });
function formatCurrency(value) {
    if (typeof value !== 'number') value = Number(value) || 0;
    return currencyFormatter.format(value);
}

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    // Set today's date as default
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('date').value = today;
    document.getElementById('editDate').value = today;
    
    // Load initial data
    loadExpenses();
    
    // Initialize charts
    initializeCharts();
    
    // Set up event listeners
    setupEventListeners();
});

function setupEventListeners() {
    // Add expense form
    document.getElementById('expenseForm').addEventListener('submit', addExpense);
    
    // Filter expenses
    document.getElementById('filterBtn').addEventListener('click', filterExpenses);
    document.getElementById('clearFilterBtn').addEventListener('click', clearFilters);
    
    // Modal close button
    document.querySelector('.close').addEventListener('click', closeModal);
    
    // Edit expense form
    document.getElementById('editExpenseForm').addEventListener('submit', updateExpense);
    
    // Close modal when clicking outside
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('editModal');
        if (event.target === modal) {
            closeModal();
        }
    });
}

async function loadExpenses(startDate = '', endDate = '') {
    try {
        let url = `${API_URL}/summary`;
        if (startDate && endDate) {
            url += `?startDate=${startDate}&endDate=${endDate}`;
        }
        
        const response = await fetch(url);
        const data = await response.json();
        
        expenses = data.expenses;
        updateDashboard(data.summary, data.total);
        updateExpensesTable();
        updateCharts();
    } catch (error) {
        console.error('Error loading expenses:', error);
        alert('Error loading expenses. Please try again.');
    }
}

function updateDashboard(summary, total) {
    // Update total amount
    document.getElementById('totalAmount').textContent = formatCurrency(total);
    
    // Update category amounts
    document.getElementById('foodAmount').textContent = formatCurrency(summary.food || 0);
    document.getElementById('travelAmount').textContent = formatCurrency(summary.travel || 0);
    document.getElementById('shoppingAmount').textContent = formatCurrency(summary.shopping || 0);
}

function updateExpensesTable() {
    const tableBody = document.getElementById('expensesTableBody');
    tableBody.innerHTML = '';
    
    expenses.forEach(expense => {
        const row = document.createElement('tr');
        
        const date = new Date(expense.date).toLocaleDateString();
        const amount = formatCurrency(expense.amount);
        const categoryClass = `category-${expense.category}`;
        
        row.innerHTML = `
            <td>${date}</td>
            <td>${expense.description}</td>
            <td><span class="category-badge ${categoryClass}">${expense.category}</span></td>
                    <td>${amount}</td>
            <td>
                <button class="btn btn-secondary" onclick="editExpense('${expense._id}')">
                    <i class="fas fa-edit"></i> Edit
                </button>
                <button class="btn btn-danger" onclick="deleteExpense('${expense._id}')">
                    <i class="fas fa-trash"></i> Delete
                </button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}

async function addExpense(e) {
    e.preventDefault();
    
    const expense = {
        description: document.getElementById('description').value,
        amount: parseFloat(document.getElementById('amount').value),
        category: document.getElementById('category').value,
        date: document.getElementById('date').value
    };
    
    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(expense)
        });
        
        if (response.ok) {
            // Clear form
            document.getElementById('expenseForm').reset();
            document.getElementById('date').value = new Date().toISOString().split('T')[0];
            
            // Reload expenses
            loadExpenses();
        } else {
            throw new Error('Failed to add expense');
        }
    } catch (error) {
        console.error('Error adding expense:', error);
        alert('Error adding expense. Please try again.');
    }
}

async function editExpense(id) {
    const expense = expenses.find(e => e._id === id);
    if (!expense) return;
    
    document.getElementById('editId').value = expense._id;
    document.getElementById('editDescription').value = expense.description;
    document.getElementById('editAmount').value = expense.amount;
    document.getElementById('editCategory').value = expense.category;
    document.getElementById('editDate').value = new Date(expense.date).toISOString().split('T')[0];
    
    // Show modal
    document.getElementById('editModal').style.display = 'block';
}

async function updateExpense(e) {
    e.preventDefault();
    
    const id = document.getElementById('editId').value;
    const expense = {
        description: document.getElementById('editDescription').value,
        amount: parseFloat(document.getElementById('editAmount').value),
        category: document.getElementById('editCategory').value,
        date: document.getElementById('editDate').value
    };
    
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(expense)
        });
        
        if (response.ok) {
            closeModal();
            loadExpenses();
        } else {
            throw new Error('Failed to update expense');
        }
    } catch (error) {
        console.error('Error updating expense:', error);
        alert('Error updating expense. Please try again.');
    }
}

async function deleteExpense(id) {
    if (!confirm('Are you sure you want to delete this expense?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_URL}/${id}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            loadExpenses();
        } else {
            throw new Error('Failed to delete expense');
        }
    } catch (error) {
        console.error('Error deleting expense:', error);
        alert('Error deleting expense. Please try again.');
    }
}

function filterExpenses() {
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    
    if (startDate && endDate) {
        loadExpenses(startDate, endDate);
    } else {
        alert('Please select both start and end dates');
    }
}

function clearFilters() {
    document.getElementById('startDate').value = '';
    document.getElementById('endDate').value = '';
    loadExpenses();
}

function closeModal() {
    document.getElementById('editModal').style.display = 'none';
}

function initializeCharts() {
    const pieCtx = document.getElementById('pieChart').getContext('2d');
    const barCtx = document.getElementById('barChart').getContext('2d');
    
    pieChart = new Chart(pieCtx, {
        type: 'pie',
        data: {
            labels: ['Food', 'Travel', 'Shopping', 'Other'],
            datasets: [{
                data: [0, 0, 0, 0],
                backgroundColor: [
                    '#4CAF50',
                    '#2196F3',
                    '#FF9800',
                    '#9C27B0'
                ],
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                }
            }
        }
    });
    
    barChart = new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [{
                label: 'Expenses',
                data: [],
                backgroundColor: '#667eea',
                borderColor: '#764ba2',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return formatCurrency(value);
                        }
                    }
                }
            }
        }
    });
}

function updateCharts() {
    // Calculate category totals for pie chart
    const categoryTotals = {
        food: 0,
        travel: 0,
        shopping: 0,
        other: 0
    };
    
    expenses.forEach(expense => {
        categoryTotals[expense.category] = (categoryTotals[expense.category] || 0) + expense.amount;
    });
    
    // Update pie chart
    pieChart.data.datasets[0].data = [
        categoryTotals.food,
        categoryTotals.travel,
        categoryTotals.shopping,
        categoryTotals.other
    ];
    pieChart.update();
    
    // Calculate monthly totals for bar chart
    const monthlyTotals = {};
    expenses.forEach(expense => {
        const date = new Date(expense.date);
        const monthYear = `${date.getFullYear()}-${(date.getMonth() + 1).toString().padStart(2, '0')}`;
        monthlyTotals[monthYear] = (monthlyTotals[monthYear] || 0) + expense.amount;
    });
    
    // Sort months chronologically
    const sortedMonths = Object.keys(monthlyTotals).sort();
    
    // Update bar chart
    barChart.data.labels = sortedMonths.map(month => {
        const [year, monthNum] = month.split('-');
        return new Date(year, monthNum - 1).toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
    });
    barChart.data.datasets[0].data = sortedMonths.map(month => monthlyTotals[month]);
    barChart.update();
}