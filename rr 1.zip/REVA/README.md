# Expense Tracker

Simple full-stack Expense Tracker (frontend + Express + MongoDB) bundled in this workspace.

## Overview
- Frontend: a static HTML/CSS/JS UI that displays expenses, charts and lets users add/edit/delete entries.
- Backend: Express API persisting expenses to MongoDB using Mongoose.

## Why store data
- Persistence across reloads and devices
- Querying, filtering and generating summaries
- Centralized multi-device access and history for analytics

## Features
- Add, edit, delete expenses
- Filter by date range
- Category summary and charts
- Currency display formatted as Indian Rupees (INR)

## Tech stack
- Frontend: plain HTML/CSS/JavaScript, Chart.js
- Backend: Node.js, Express, Mongoose (MongoDB)

## Prerequisites
- Node.js (v16+ recommended)
- MongoDB running locally or accessible via URI

## Backend setup (run from `Backned`)

1. Install dependencies

```bash
cd Backned
npm install
```

2. (Optional) create a `.env` file with:

```
MONGODB_URI=mongodb://localhost:27017/expense-tracker
PORT=5000
```

3. Start the backend

```bash
npm run dev    # uses nodemon
```

The backend serves the API at `http://localhost:5000/api/expenses` by default.

## Frontend
- Open `Frontend/index.html` in a browser, or serve it with a simple static server (recommended for correct fetch behavior).

Quick static server example (from repository root):

```bash
# using Node's http-server (install globally or with npx)
npx http-server Frontend -p 8080
# then open http://localhost:8080
```

## API Endpoints
- `GET /api/expenses` — list all expenses
- `GET /api/expenses/summary?startDate=YYYY-MM-DD&endDate=YYYY-MM-DD` — get filtered expenses, category summary and total
- `POST /api/expenses` — add expense (JSON body: `description`, `amount`, `category`, `date`)
- `PUT /api/expenses/:id` — update expense
- `DELETE /api/expenses/:id` — delete expense

Example: add an expense

```bash
curl -X POST http://localhost:5000/api/expenses \
  -H "Content-Type: application/json" \
  -d '{"description":"Lunch","amount":150,"category":"food","date":"2026-01-20"}'
```

## INR currency
- The frontend now formats and displays amounts as Indian Rupees (₹). See `Frontend/script.js` where `Intl.NumberFormat('en-IN', { currency: 'INR' })` is used.

## Important files
- [Backned/server.js](Backned/server.js) — server entry
- [Backned/routes/expenses.js](Backned/routes/expenses.js) — API routes
- [Backned/models/Expense.js](Backned/models/Expense.js) — Mongoose model
- [Backned/package.json](Backned/package.json) — backend dependencies & scripts
- [Frontend/index.html](Frontend/index.html) — UI
- [Frontend/script.js](Frontend/script.js) — frontend logic and API calls

## Troubleshooting
- If fetch calls fail in the browser, ensure backend is running and CORS is enabled (it is by default in `Backned/server.js`).
- If MongoDB connection fails, verify `MONGODB_URI` and that MongoDB is running.

If you want, I can start the backend here and run a quick end-to-end check.